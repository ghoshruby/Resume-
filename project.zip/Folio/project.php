<?php
$name=$_POST['name'];
$email=$_POST['email'];
$subject=$_POST['subject'];
$message=$_POST['message'];
echo($name.$email.$subject.$message);
$connect=mysqli_connect('localhost','root','','details');
$insert="INSERT into project SET name='$name',email='$email',subject='$subject',message='$message'";
$connect->query($insert);

?>