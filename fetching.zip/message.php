<?php


 $connect=mysqli_connect('localhost','root','','details');
 
$query="SELECT * FROM message";
$data = mysqli_query($connect,$query);
$total=mysqli_num_rows($data);

if($total !=0)
{
    ?>
    <table style="font-size:24px; font-family:Comic Sans MS">
    <?php
    while($result=mysqli_fetch_assoc($data)) 
    {
        echo "<tr>
        <td>" .$result['message']."</td>
        </tr>";
    }
}
else{
    echo "no record found";

}
?>
</table>












