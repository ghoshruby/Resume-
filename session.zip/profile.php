<?php 
session_start();
if(!(isset($_SESSION['username'])))
{
    header('Location: index.html');
}
?>

<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body style="background-color: yellow;">

	<a href="logout.php">Logout</a><br><br>

	<?php 
		if($_SESSION['username']!=NULL) 
		{  
   			 echo "your username is:".$_SESSION['username']; 
		} 

	?>

</body>
</html>