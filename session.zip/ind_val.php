<?php 
include("connection.php");

if(isset($_POST['button']))
	{
    session_start();  
    $username=$_POST["username"];
	$password=$_POST["password"];
	$select="SELECT * FROM username] where username='$username' and password='$password'";
	$select01=($conn->query($select));
	$row=mysqli_num_rows($select01);

		if($row==1)
			{

   				 $_SESSION['username']=$username; 
					header('location:profile.php'); 
					echo("$username.$password");
   			}
	}

else{
		echo "tried it";
	}
?>